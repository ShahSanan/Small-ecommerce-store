from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name='home'),
    path("about", views.about, name='about'),
    path("service", views.service, name='service'),
    path("buy", views.buy, name='buy'),
    path("shake", views.shake, name='shake'),
    path("checkout", views.checkout, name='checkout'),
    path("pay", views.pay, name='pay'),

]
