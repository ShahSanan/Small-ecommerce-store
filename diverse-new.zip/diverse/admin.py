from django.contrib import admin
from diverse.models import Checkout
# Register your models here.
admin.site.register(Checkout)